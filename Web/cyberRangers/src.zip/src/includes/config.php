<?php

$server_ip = $_SERVER['SERVER_ADDR'];
$server_port = $_SERVER['SERVER_PORT'];

$base_url = "http://{$server_ip}:{$server_port}";  
$upload_dir = "/uploads"; 

?>
